"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var db_exports = {};
__export(db_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(db_exports);
var import_pg = require("pg");
const log = (...args) => {
  console.log("[DB Function]", ...args);
};
const handler = async (event, context) => {
  log("Request received:", {
    method: event.httpMethod,
    path: event.path,
    body: event.body ? JSON.parse(event.body) : {},
    env: {
      DB_USER: process.env.DB_USER ? "***" : "not set",
      DB_HOST: process.env.DB_HOST ? "***" : "not set",
      DB_NAME: process.env.DB_NAME ? "***" : "not set",
      DB_PORT: process.env.DB_PORT ? "***" : "not set"
    }
  });
  if (event.httpMethod !== "POST") {
    const error = "Method Not Allowed";
    log("Error:", error);
    return {
      statusCode: 405,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: JSON.stringify({ error })
    };
  }
  let pool;
  try {
    const dbConfig = {
      user: process.env.DB_USER || "routeuser",
      host: process.env.DB_HOST || "localhost",
      database: process.env.DB_NAME || "routedb",
      password: process.env.DB_PASSWORD ? "***" : "not set",
      port: parseInt(process.env.DB_PORT || "5432")
    };
    log("Creating database connection with config:", { ...dbConfig, password: "***" });
    pool = new import_pg.Pool(dbConfig);
    try {
      const testResult = await pool.query("SELECT NOW()");
      log("Database connection test successful:", testResult.rows[0]);
    } catch (testError) {
      log("Database connection test failed:", testError);
      throw new Error(`Database connection test failed: ${testError.message}`);
    }
    const { query, params = [] } = JSON.parse(event.body);
    log("Executing query:", { query, params });
    const result = await pool.query(query, params);
    log("Query successful, rows returned:", result.rows.length);
    const queryResult = {
      rows: result.rows,
      rowCount: result.rowCount
    };
    log("Returning query result with row count:", queryResult.rowCount);
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: JSON.stringify(queryResult)
    };
  } catch (error) {
    log("Database error:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: JSON.stringify({
        error: error.message,
        details: error.detail,
        code: error.code,
        query: error.query
      })
    };
  } finally {
    if (pool) {
      try {
        await pool.end();
        log("Database connection closed");
      } catch (err) {
        log("Error closing connection:", err);
      }
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
